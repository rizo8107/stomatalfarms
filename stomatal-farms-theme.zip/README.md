# Stomatal Farms - Shopify Theme

A custom Shopify theme converted from the React-based Muse Scent Studio application. This theme is designed for artisanal fragrance and scent products.

## Features

- **Modern Design**: Clean, elegant design optimized for fragrance products
- **Responsive**: Fully responsive layout that works on all devices
- **Product Showcase**: Beautiful product cards with discount badges and quick add-to-cart
- **Collections**: Organized product categories and collections
- **Cart Functionality**: Ajax-powered cart with real-time updates
- **SEO Optimized**: Proper meta tags and structured data
- **Customizable**: Theme settings for colors, fonts, and layout options

## Theme Structure

```
shopify-theme/
├── assets/           # CSS, JavaScript, and image files
│   ├── base.css
│   ├── theme.css
│   ├── global.js
│   └── cart.js
├── config/           # Theme configuration
│   ├── settings_schema.json
│   └── settings_data.json
├── layout/           # Theme layouts
│   └── theme.liquid
├── locales/          # Translation files
│   └── en.default.json
├── sections/         # Reusable sections
│   ├── header.liquid
│   ├── footer.liquid
│   ├── hero-section.liquid
│   ├── features-bar.liquid
│   ├── craft-purity.liquid
│   ├── product-categories.liquid
│   ├── featured-collection.liquid
│   ├── rituals-section.liquid
│   ├── main-product.liquid
│   ├── main-collection-product-grid.liquid
│   ├── collection-banner.liquid
│   └── related-products.liquid
├── snippets/         # Reusable snippets
│   ├── product-card.liquid
│   ├── product-variant-picker.liquid
│   ├── meta-tags.liquid
│   ├── social-share.liquid
│   └── collection-filters.liquid
└── templates/        # Page templates
    ├── index.json
    ├── collection.json
    ├── product.json
    └── cart.json
```

## Installation

### Method 1: Using Shopify CLI (Recommended)

1. **Install Shopify CLI**
   ```bash
   npm install -g @shopify/cli @shopify/theme
   ```

2. **Navigate to the theme directory**
   ```bash
   cd shopify-theme
   ```

3. **Login to Shopify**
   ```bash
   shopify auth login
   ```

4. **Push theme to your store**
   ```bash
   shopify theme push
   ```

5. **Or develop locally with live preview**
   ```bash
   shopify theme dev
   ```

### Method 2: Manual Upload via Shopify Admin

1. **Create a ZIP file**
   - Compress the entire `shopify-theme` folder into a ZIP file
   - Make sure the folder structure is preserved (assets, config, layout, etc. should be at the root of the ZIP)

2. **Upload to Shopify**
   - Go to your Shopify Admin
   - Navigate to **Online Store > Themes**
   - Click **Add theme** > **Upload ZIP file**
   - Select your ZIP file and upload

3. **Publish the theme**
   - Once uploaded, click **Publish** to make it your live theme
   - Or click **Customize** to edit it in the theme editor first

## Configuration

### Theme Settings

Access theme settings via **Online Store > Themes > Customize**:

1. **Colors**
   - Primary color
   - Accent color
   - Text color
   - Background color

2. **Typography**
   - Heading font
   - Body font

3. **Layout**
   - Page width
   - Spacing options

4. **Social Media**
   - Add your social media links

### Homepage Setup

The homepage uses the following sections (in order):
1. **Hero Section** - Main banner with heading and CTA
2. **Features Bar** - Highlight key features (free shipping, natural ingredients, etc.)
3. **Craft & Purity** - About section with image and text
4. **Product Categories** - Showcase collections
5. **Featured Products** - Display products from a selected collection
6. **Rituals Section** - Lifestyle/usage scenarios

To customize:
1. Go to **Online Store > Themes > Customize**
2. Select the homepage
3. Click on each section to edit content
4. Add/remove/reorder sections as needed

### Navigation Setup

1. **Create menus**
   - Go to **Online Store > Navigation**
   - Create a menu called "main-menu" for header navigation
   - Create a menu called "footer" for footer links

2. **Header Menu Items** (suggested):
   - Home
   - Shop (link to /collections/all)
   - About
   - Contact

### Collections Setup

1. **Create Collections**
   - Go to **Products > Collections**
   - Create collections for your product categories (e.g., "Perfumes", "Essential Oils", "Candles")

2. **Add Collection Images**
   - Edit each collection
   - Upload a featured image
   - Add description

3. **Link to Product Categories Section**
   - In theme customizer, edit the "Product Categories" section
   - Add blocks for each collection
   - Select the collection and customize title/description

## Customization Tips

### Adding Custom CSS

1. Edit `assets/theme.css`
2. Add your custom styles at the end of the file
3. Use CSS variables for consistency:
   ```css
   .my-custom-class {
     color: var(--color-primary);
     padding: var(--spacing-md);
   }
   ```

### Modifying Product Cards

Edit `snippets/product-card.liquid` to change:
- Product image size
- Price display format
- Add to cart button style
- Badge appearance

### Changing Layout

Edit `layout/theme.liquid` to:
- Add custom scripts
- Modify meta tags
- Change overall page structure

## Development

### Local Development

```bash
# Install Shopify CLI
npm install -g @shopify/cli @shopify/theme

# Navigate to theme directory
cd shopify-theme

# Start development server
shopify theme dev
```

This will:
- Start a local development server
- Watch for file changes
- Sync changes to your development theme
- Provide a preview URL

### Best Practices

1. **Always test on a development theme first**
2. **Use version control** (Git) to track changes
3. **Backup your theme** before making major changes
4. **Test on multiple devices** and browsers
5. **Optimize images** before uploading
6. **Use Shopify's built-in CDN** for assets

## Troubleshooting

### Theme not appearing after upload
- Ensure the ZIP file has the correct structure (folders should be at root level)
- Check that all required files are present (layout/theme.liquid is essential)

### Sections not showing
- Verify section files are in the `sections/` folder
- Check JSON syntax in template files
- Ensure section schema is valid

### JavaScript not working
- Check browser console for errors
- Verify asset files are loading correctly
- Clear browser cache

### Styles not applying
- Check CSS file paths in layout/theme.liquid
- Verify CSS syntax
- Clear Shopify theme cache

## Support

For issues or questions:
1. Check Shopify's theme documentation: https://shopify.dev/themes
2. Review Liquid documentation: https://shopify.dev/api/liquid
3. Check browser console for JavaScript errors
4. Verify theme file structure matches Shopify requirements

## Conversion Notes

This theme was converted from a React/Vite SPA to a Shopify Liquid theme. Key changes:

- **React components** → **Liquid sections/snippets**
- **React Router** → **Shopify page templates**
- **Zustand state management** → **Shopify Ajax Cart API**
- **TailwindCSS** → **Custom CSS with design tokens**
- **shadcn/ui components** → **Custom HTML/CSS components**

## License

Custom theme for Stomatal Farms. All rights reserved.

## Credits

- Original React application: Muse Scent Studio
- Converted to Shopify theme: 2026
- Framework: Shopify Liquid
