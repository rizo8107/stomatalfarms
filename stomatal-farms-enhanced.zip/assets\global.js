// Global JavaScript for Stomatal Farms Theme

// Mobile Menu Toggle
document.addEventListener('DOMContentLoaded', function() {
  const menuToggle = document.getElementById('mobile-menu-toggle');
  const mobileNav = document.getElementById('mobile-nav');
  const menuIcon = menuToggle?.querySelector('.menu-icon');
  const closeIcon = menuToggle?.querySelector('.close-icon');
  
  if (menuToggle && mobileNav) {
    menuToggle.addEventListener('click', function() {
      mobileNav.classList.toggle('active');
      menuIcon?.classList.toggle('hidden');
      closeIcon?.classList.toggle('hidden');
    });
  }
  
  // Close mobile menu when clicking outside
  document.addEventListener('click', function(event) {
    if (mobileNav && !mobileNav.contains(event.target) && !menuToggle?.contains(event.target)) {
      mobileNav.classList.remove('active');
      menuIcon?.classList.remove('hidden');
      closeIcon?.classList.add('hidden');
    }
  });
});

// Update cart count
function updateCartCount(count) {
  const cartCountElements = document.querySelectorAll('#cart-count, [data-cart-count]');
  cartCountElements.forEach(element => {
    element.textContent = count;
    if (count > 0) {
      element.style.display = '';
    } else {
      element.style.display = 'none';
    }
  });
}

// Fetch cart data
async function fetchCart() {
  try {
    const response = await fetch('/cart.js');
    const cart = await response.json();
    updateCartCount(cart.item_count);
    return cart;
  } catch (error) {
    console.error('Error fetching cart:', error);
    return null;
  }
}

// Add to cart from product cards
document.addEventListener('click', function(event) {
  const addToCartButton = event.target.closest('.product-card__add-to-cart');
  
  if (addToCartButton && !addToCartButton.disabled) {
    event.preventDefault();
    event.stopPropagation();
    
    const variantId = addToCartButton.dataset.variantId;
    const productId = addToCartButton.dataset.productId;
    
    if (variantId) {
      addToCart(variantId, 1, addToCartButton);
    }
  }
});

// Add to cart function
async function addToCart(variantId, quantity = 1, button = null) {
  const originalText = button?.textContent;
  
  if (button) {
    button.disabled = true;
    button.textContent = 'Adding...';
  }
  
  try {
    const response = await fetch('/cart/add.js', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        id: variantId,
        quantity: quantity
      })
    });
    
    if (response.ok) {
      const item = await response.json();
      await fetchCart();
      
      if (button) {
        button.textContent = 'Added!';
        setTimeout(() => {
          button.textContent = originalText;
          button.disabled = false;
        }, 2000);
      }
      
      showNotification('Added to cart successfully!', 'success');
    } else {
      throw new Error('Failed to add to cart');
    }
  } catch (error) {
    console.error('Error adding to cart:', error);
    
    if (button) {
      button.textContent = originalText;
      button.disabled = false;
    }
    
    showNotification('Failed to add to cart. Please try again.', 'error');
  }
}

// Simple notification system
function showNotification(message, type = 'info') {
  const notification = document.createElement('div');
  notification.className = `notification notification--${type}`;
  notification.textContent = message;
  notification.style.cssText = `
    position: fixed;
    top: 100px;
    right: 20px;
    background: ${type === 'success' ? '#10b981' : type === 'error' ? '#ef4444' : '#3b82f6'};
    color: white;
    padding: 1rem 1.5rem;
    border-radius: 0.5rem;
    box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.1);
    z-index: 9999;
    animation: slideIn 0.3s ease;
  `;
  
  document.body.appendChild(notification);
  
  setTimeout(() => {
    notification.style.animation = 'slideOut 0.3s ease';
    setTimeout(() => {
      notification.remove();
    }, 300);
  }, 3000);
}

// Add animation styles
const style = document.createElement('style');
style.textContent = `
  @keyframes slideIn {
    from {
      transform: translateX(100%);
      opacity: 0;
    }
    to {
      transform: translateX(0);
      opacity: 1;
    }
  }
  
  @keyframes slideOut {
    from {
      transform: translateX(0);
      opacity: 1;
    }
    to {
      transform: translateX(100%);
      opacity: 0;
    }
  }
  
  .hidden {
    display: none !important;
  }
`;
document.head.appendChild(style);

// Initialize cart count on page load
fetchCart();

// Shopify money format helper
if (typeof Shopify === 'undefined') {
  window.Shopify = {};
}

Shopify.formatMoney = function(cents, format) {
  if (typeof cents === 'string') {
    cents = cents.replace('.', '');
  }
  
  let value = '';
  const placeholderRegex = /\{\{\s*(\w+)\s*\}\}/;
  const formatString = format || '₹{{amount}}';
  
  function formatWithDelimiters(number, precision, thousands, decimal) {
    precision = precision || 2;
    thousands = thousands || ',';
    decimal = decimal || '.';
    
    if (isNaN(number) || number == null) {
      return 0;
    }
    
    number = (number / 100.0).toFixed(precision);
    
    const parts = number.split('.');
    const dollarsAmount = parts[0].replace(/(\d)(?=(\d\d\d)+(?!\d))/g, '$1' + thousands);
    const centsAmount = parts[1] ? (decimal + parts[1]) : '';
    
    return dollarsAmount + centsAmount;
  }
  
  switch (formatString.match(placeholderRegex)[1]) {
    case 'amount':
      value = formatWithDelimiters(cents, 2);
      break;
    case 'amount_no_decimals':
      value = formatWithDelimiters(cents, 0);
      break;
    case 'amount_with_comma_separator':
      value = formatWithDelimiters(cents, 2, '.', ',');
      break;
    case 'amount_no_decimals_with_comma_separator':
      value = formatWithDelimiters(cents, 0, '.', ',');
      break;
  }
  
  return formatString.replace(placeholderRegex, value);
};
