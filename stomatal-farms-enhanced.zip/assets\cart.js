// Cart functionality for Stomatal Farms Theme

class Cart {
  constructor() {
    this.cart = null;
    this.init();
  }
  
  async init() {
    await this.fetchCart();
    this.bindEvents();
  }
  
  async fetchCart() {
    try {
      const response = await fetch('/cart.js');
      this.cart = await response.json();
      this.updateCartUI();
      return this.cart;
    } catch (error) {
      console.error('Error fetching cart:', error);
      return null;
    }
  }
  
  async addItem(variantId, quantity = 1, properties = {}) {
    try {
      const response = await fetch('/cart/add.js', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          id: variantId,
          quantity: quantity,
          properties: properties
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to add item to cart');
      }
      
      const item = await response.json();
      await this.fetchCart();
      return item;
    } catch (error) {
      console.error('Error adding item to cart:', error);
      throw error;
    }
  }
  
  async updateItem(line, quantity) {
    try {
      const response = await fetch('/cart/change.js', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          line: line,
          quantity: quantity
        })
      });
      
      if (!response.ok) {
        throw new Error('Failed to update cart item');
      }
      
      this.cart = await response.json();
      this.updateCartUI();
      return this.cart;
    } catch (error) {
      console.error('Error updating cart item:', error);
      throw error;
    }
  }
  
  async removeItem(line) {
    return this.updateItem(line, 0);
  }
  
  async clearCart() {
    try {
      const response = await fetch('/cart/clear.js', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        }
      });
      
      if (!response.ok) {
        throw new Error('Failed to clear cart');
      }
      
      await this.fetchCart();
      return this.cart;
    } catch (error) {
      console.error('Error clearing cart:', error);
      throw error;
    }
  }
  
  updateCartUI() {
    if (!this.cart) return;
    
    // Update cart count
    const cartCountElements = document.querySelectorAll('#cart-count, [data-cart-count]');
    cartCountElements.forEach(element => {
      element.textContent = this.cart.item_count;
      if (this.cart.item_count > 0) {
        element.style.display = '';
      } else {
        element.style.display = 'none';
      }
    });
    
    // Update cart items if on cart page
    this.updateCartPage();
  }
  
  updateCartPage() {
    const cartItemsContainer = document.querySelector('[data-cart-items]');
    if (!cartItemsContainer || !this.cart) return;
    
    if (this.cart.items.length === 0) {
      cartItemsContainer.innerHTML = '<p class="cart-empty">Your cart is empty.</p>';
      return;
    }
    
    // Update cart items
    this.cart.items.forEach((item, index) => {
      const itemElement = document.querySelector(`[data-cart-item="${index + 1}"]`);
      if (itemElement) {
        const quantityInput = itemElement.querySelector('[data-quantity-input]');
        const lineTotal = itemElement.querySelector('[data-line-total]');
        
        if (quantityInput) {
          quantityInput.value = item.quantity;
        }
        
        if (lineTotal) {
          lineTotal.textContent = Shopify.formatMoney(item.line_price);
        }
      }
    });
    
    // Update cart total
    const cartTotal = document.querySelector('[data-cart-total]');
    if (cartTotal) {
      cartTotal.textContent = Shopify.formatMoney(this.cart.total_price);
    }
  }
  
  bindEvents() {
    // Handle quantity changes
    document.addEventListener('change', async (event) => {
      const quantityInput = event.target.closest('[data-quantity-input]');
      if (quantityInput) {
        const line = parseInt(quantityInput.dataset.line);
        const quantity = parseInt(quantityInput.value);
        
        if (quantity >= 0) {
          try {
            await this.updateItem(line, quantity);
          } catch (error) {
            console.error('Failed to update quantity:', error);
            quantityInput.value = quantityInput.dataset.originalValue || 1;
          }
        }
      }
    });
    
    // Handle remove buttons
    document.addEventListener('click', async (event) => {
      const removeButton = event.target.closest('[data-cart-remove]');
      if (removeButton) {
        event.preventDefault();
        const line = parseInt(removeButton.dataset.line);
        
        try {
          await this.removeItem(line);
        } catch (error) {
          console.error('Failed to remove item:', error);
        }
      }
    });
  }
}

// Initialize cart
if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', () => {
    window.cartInstance = new Cart();
  });
} else {
  window.cartInstance = new Cart();
}
